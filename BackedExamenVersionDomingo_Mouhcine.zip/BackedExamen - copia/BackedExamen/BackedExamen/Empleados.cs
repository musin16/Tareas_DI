﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackedExamen
{
    class Empleados
    {
        string dni;
        string pasword;
        int nivel;
        float ventas;

        public Empleados()
        {
        }

        public Empleados(string dni, string pasword, int nivel, float ventas)
        {
            this.Dni = dni;
            this.Pasword = pasword;
            this.Nivel = nivel;
            this.Ventas = ventas;
        }

        public string Dni { get => dni; set => dni = value; }
        public string Pasword { get => pasword; set => pasword = value; }
        public int Nivel { get => nivel; set => nivel = value; }
        public float Ventas { get => ventas; set => ventas = value; }
    }
}