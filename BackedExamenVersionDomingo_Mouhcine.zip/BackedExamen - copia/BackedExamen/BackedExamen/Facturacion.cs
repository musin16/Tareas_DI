﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackedExamen
{
    class Facturacion
    {
        int indice;
        string mail;
        string cadenaProd;
        DateTime fecha;
        float total;
        public Facturacion()
        {

        }   
       public  Facturacion(int indice, string mail, string cadenaProd, DateTime fecha, float total)
        {
            this.Indice = indice;
            this.Mail = mail;
            this.CadenaProd = cadenaProd;
            this.Fecha = fecha;
            this.Total = total;
        }

        public int Indice { get => indice; set => indice = value; }
        public string Mail { get => mail; set => mail = value; }
        public string CadenaProd { get => cadenaProd; set => cadenaProd = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public float Total { get => total; set => total = value; }
    }
}
