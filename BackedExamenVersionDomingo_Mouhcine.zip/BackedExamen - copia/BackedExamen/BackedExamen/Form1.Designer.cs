﻿
namespace BackedExamen
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_BorrarTabla = new System.Windows.Forms.Button();
            this.btnCreatTienda = new System.Windows.Forms.Button();
            this.btn_anadirProductos = new System.Windows.Forms.Button();
            this.gbStockBajoMinimo = new System.Windows.Forms.GroupBox();
            this.btn_anadirCli = new System.Windows.Forms.Button();
            this.txtProve = new System.Windows.Forms.TextBox();
            this.txtcantidad = new System.Windows.Forms.TextBox();
            this.txtProd = new System.Windows.Forms.TextBox();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.lblCantidadStockIntroducir = new System.Windows.Forms.Label();
            this.lblProductStock = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnOpciones = new System.Windows.Forms.Button();
            this.dgvStockNecesario = new System.Windows.Forms.DataGridView();
            this.btnGenerarInforme = new System.Windows.Forms.Button();
            this.btn_Salir = new System.Windows.Forms.Button();
            this.dgvInforme = new System.Windows.Forms.DataGridView();
            this.gbStockBajoMinimo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStockNecesario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInforme)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_BorrarTabla
            // 
            this.btn_BorrarTabla.Location = new System.Drawing.Point(116, 194);
            this.btn_BorrarTabla.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_BorrarTabla.Name = "btn_BorrarTabla";
            this.btn_BorrarTabla.Size = new System.Drawing.Size(153, 65);
            this.btn_BorrarTabla.TabIndex = 0;
            this.btn_BorrarTabla.Text = "Borrar Tabla";
            this.btn_BorrarTabla.UseVisualStyleBackColor = true;
            this.btn_BorrarTabla.Click += new System.EventHandler(this.btn_alta_Click);
            // 
            // btnCreatTienda
            // 
            this.btnCreatTienda.Location = new System.Drawing.Point(116, 85);
            this.btnCreatTienda.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCreatTienda.Name = "btnCreatTienda";
            this.btnCreatTienda.Size = new System.Drawing.Size(153, 65);
            this.btnCreatTienda.TabIndex = 1;
            this.btnCreatTienda.Text = "Crear Tienda";
            this.btnCreatTienda.UseVisualStyleBackColor = true;
            this.btnCreatTienda.Click += new System.EventHandler(this.btnCreatTienda_Click);
            // 
            // btn_anadirProductos
            // 
            this.btn_anadirProductos.Location = new System.Drawing.Point(116, 285);
            this.btn_anadirProductos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_anadirProductos.Name = "btn_anadirProductos";
            this.btn_anadirProductos.Size = new System.Drawing.Size(153, 65);
            this.btn_anadirProductos.TabIndex = 3;
            this.btn_anadirProductos.Text = "Añadir Pedido Manual";
            this.btn_anadirProductos.UseVisualStyleBackColor = true;
            this.btn_anadirProductos.Click += new System.EventHandler(this.btn_anadirProductos_Click);
            // 
            // gbStockBajoMinimo
            // 
            this.gbStockBajoMinimo.Controls.Add(this.btn_anadirCli);
            this.gbStockBajoMinimo.Controls.Add(this.txtProve);
            this.gbStockBajoMinimo.Controls.Add(this.txtcantidad);
            this.gbStockBajoMinimo.Controls.Add(this.txtProd);
            this.gbStockBajoMinimo.Controls.Add(this.lblProveedor);
            this.gbStockBajoMinimo.Controls.Add(this.lblCantidadStockIntroducir);
            this.gbStockBajoMinimo.Controls.Add(this.lblProductStock);
            this.gbStockBajoMinimo.Location = new System.Drawing.Point(297, 285);
            this.gbStockBajoMinimo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbStockBajoMinimo.Name = "gbStockBajoMinimo";
            this.gbStockBajoMinimo.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbStockBajoMinimo.Size = new System.Drawing.Size(346, 242);
            this.gbStockBajoMinimo.TabIndex = 7;
            this.gbStockBajoMinimo.TabStop = false;
            this.gbStockBajoMinimo.Text = "Producto con Stock debajo del minimo";
            this.gbStockBajoMinimo.Visible = false;
            // 
            // btn_anadirCli
            // 
            this.btn_anadirCli.Location = new System.Drawing.Point(156, 177);
            this.btn_anadirCli.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_anadirCli.Name = "btn_anadirCli";
            this.btn_anadirCli.Size = new System.Drawing.Size(112, 35);
            this.btn_anadirCli.TabIndex = 10;
            this.btn_anadirCli.Text = "Añadir";
            this.btn_anadirCli.UseVisualStyleBackColor = true;
            this.btn_anadirCli.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtProve
            // 
            this.txtProve.Location = new System.Drawing.Point(142, 125);
            this.txtProve.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtProve.Name = "txtProve";
            this.txtProve.Size = new System.Drawing.Size(148, 26);
            this.txtProve.TabIndex = 9;
            // 
            // txtcantidad
            // 
            this.txtcantidad.Location = new System.Drawing.Point(142, 74);
            this.txtcantidad.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcantidad.Name = "txtcantidad";
            this.txtcantidad.Size = new System.Drawing.Size(148, 26);
            this.txtcantidad.TabIndex = 8;
            // 
            // txtProd
            // 
            this.txtProd.Location = new System.Drawing.Point(142, 25);
            this.txtProd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtProd.Name = "txtProd";
            this.txtProd.Size = new System.Drawing.Size(148, 26);
            this.txtProd.TabIndex = 7;
            this.txtProd.TextChanged += new System.EventHandler(this.txtProd_TextChanged);
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(30, 125);
            this.lblProveedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(80, 20);
            this.lblProveedor.TabIndex = 6;
            this.lblProveedor.Text = "proveedor";
            // 
            // lblCantidadStockIntroducir
            // 
            this.lblCantidadStockIntroducir.AutoSize = true;
            this.lblCantidadStockIntroducir.Location = new System.Drawing.Point(30, 72);
            this.lblCantidadStockIntroducir.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantidadStockIntroducir.Name = "lblCantidadStockIntroducir";
            this.lblCantidadStockIntroducir.Size = new System.Drawing.Size(70, 20);
            this.lblCantidadStockIntroducir.TabIndex = 5;
            this.lblCantidadStockIntroducir.Text = "cantidad";
            // 
            // lblProductStock
            // 
            this.lblProductStock.AutoSize = true;
            this.lblProductStock.Location = new System.Drawing.Point(30, 25);
            this.lblProductStock.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProductStock.Name = "lblProductStock";
            this.lblProductStock.Size = new System.Drawing.Size(73, 20);
            this.lblProductStock.TabIndex = 4;
            this.lblProductStock.Text = "Producto";
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnOpciones
            // 
            this.btnOpciones.Location = new System.Drawing.Point(116, 529);
            this.btnOpciones.Name = "btnOpciones";
            this.btnOpciones.Size = new System.Drawing.Size(125, 55);
            this.btnOpciones.TabIndex = 13;
            this.btnOpciones.Text = "Más Opciones";
            this.btnOpciones.UseVisualStyleBackColor = true;
            this.btnOpciones.Click += new System.EventHandler(this.btnOpciones_Click);
            // 
            // dgvStockNecesario
            // 
            this.dgvStockNecesario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStockNecesario.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvStockNecesario.Location = new System.Drawing.Point(375, 85);
            this.dgvStockNecesario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvStockNecesario.Name = "dgvStockNecesario";
            this.dgvStockNecesario.RowHeadersWidth = 62;
            this.dgvStockNecesario.Size = new System.Drawing.Size(803, 174);
            this.dgvStockNecesario.TabIndex = 8;
            this.dgvStockNecesario.Visible = false;
            // 
            // btnGenerarInforme
            // 
            this.btnGenerarInforme.Location = new System.Drawing.Point(770, 529);
            this.btnGenerarInforme.Name = "btnGenerarInforme";
            this.btnGenerarInforme.Size = new System.Drawing.Size(214, 55);
            this.btnGenerarInforme.TabIndex = 14;
            this.btnGenerarInforme.Text = "Generar Informe de ventas";
            this.btnGenerarInforme.UseVisualStyleBackColor = true;
            this.btnGenerarInforme.Click += new System.EventHandler(this.btnGenerarInforme_Click);
            // 
            // btn_Salir
            // 
            this.btn_Salir.Location = new System.Drawing.Point(1097, 583);
            this.btn_Salir.Name = "btn_Salir";
            this.btn_Salir.Size = new System.Drawing.Size(134, 51);
            this.btn_Salir.TabIndex = 15;
            this.btn_Salir.Text = "Salir";
            this.btn_Salir.UseVisualStyleBackColor = true;
            this.btn_Salir.Click += new System.EventHandler(this.btn_Salir_Click);
            // 
            // dgvInforme
            // 
            this.dgvInforme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInforme.Location = new System.Drawing.Point(650, 280);
            this.dgvInforme.Name = "dgvInforme";
            this.dgvInforme.RowHeadersWidth = 62;
            this.dgvInforme.RowTemplate.Height = 28;
            this.dgvInforme.Size = new System.Drawing.Size(625, 243);
            this.dgvInforme.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1306, 783);
            this.Controls.Add(this.dgvInforme);
            this.Controls.Add(this.btn_Salir);
            this.Controls.Add(this.btnGenerarInforme);
            this.Controls.Add(this.btnOpciones);
            this.Controls.Add(this.dgvStockNecesario);
            this.Controls.Add(this.gbStockBajoMinimo);
            this.Controls.Add(this.btn_anadirProductos);
            this.Controls.Add(this.btnCreatTienda);
            this.Controls.Add(this.btn_BorrarTabla);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbStockBajoMinimo.ResumeLayout(false);
            this.gbStockBajoMinimo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStockNecesario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInforme)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_BorrarTabla;
        private System.Windows.Forms.Button btnCreatTienda;
        private System.Windows.Forms.Button btn_anadirProductos;
        private System.Windows.Forms.GroupBox gbStockBajoMinimo;
        private System.Windows.Forms.TextBox txtProve;
        private System.Windows.Forms.TextBox txtcantidad;
        private System.Windows.Forms.TextBox txtProd;
        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label lblCantidadStockIntroducir;
        private System.Windows.Forms.Label lblProductStock;
        private System.Windows.Forms.Button btn_anadirCli;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnOpciones;
        private System.Windows.Forms.DataGridView dgvStockNecesario;
        private System.Windows.Forms.Button btnGenerarInforme;
        private System.Windows.Forms.Button btn_Salir;
        private System.Windows.Forms.DataGridView dgvInforme;
    }
}

