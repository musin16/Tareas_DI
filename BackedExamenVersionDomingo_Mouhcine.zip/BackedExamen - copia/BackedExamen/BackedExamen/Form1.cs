﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackedExamen
{
    public partial class Form1 : Form
    {
        conectarBD cnx = new conectarBD();
        List<Facturacion> facturacions = new List<Facturacion>();
        List<frutas> lisfrutas = new List<frutas>();
        List<Proveedores> listProves = new List<Proveedores>();
        List<Tiendas> lisTiendas = new List<Tiendas>();
        List<Empleados> ListEmp = new List<Empleados>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreatTienda_Click(object sender, EventArgs e)

        {
            ocultar();
            String tienda = Interaction.InputBox("Introduce el nombre de la tienda que queires crear: ");
            String mensaje = cnx.crearTienda(tienda);
            if (mensaje.Equals("Se ha creado correctamente la tienda"))
            {
                cnx.insertarTienda(tienda);
                MessageBox.Show(mensaje);
            }
            else
            {
                MessageBox.Show(mensaje);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listProves = cnx.obtenerProvedor();
            lisfrutas = cnx.mostrarTienda("frutas");
            facturacions = cnx.infoTablaFacturacion();
            if (conectarBD.cont != 1) {
                Form2 f = new Form2();
                f.Close();
                ocultar();
                btnCreatTienda.Visible = false;
                btn_BorrarTabla.Visible = false;
            }
            timer1.Start();

        }

        private void btn_alta_Click(object sender, EventArgs e)
        {
            ocultar();
            string tabla = Interaction.InputBox("Intoduce la tabla que queiras eliminar");
            string mensaje = cnx.borrarTabla(tabla);
            if (mensaje.Equals("Se ha borrado correctamente la tienda"))
            {
                cnx.borrarTienda(tabla);
                MessageBox.Show(mensaje);

            }
            else
            {
                MessageBox.Show(mensaje);
            }


        }

        public void ocultar()
        {
            gbStockBajoMinimo.Visible = false;
            dgvStockNecesario.Visible = false;
            gbStockBajoMinimo.Visible = false;

        }

        private void btn_anadirProductos_Click(object sender, EventArgs e)
        {
            ocultar();
            gbStockBajoMinimo.Visible = true;

        }
        private void button3_Click(object sender, EventArgs e)

        {
            dgvStockNecesario.DataSource = null;
            frutas fr = lisfrutas.Find(x => x.Nombre.Equals(txtProd.Text.Trim()));
            List<frutas> list = new List<frutas>();

            if (fr != null)
            {
                list.Add(fr);
                dgvStockNecesario.DataSource = list;
                dgvStockNecesario.Visible = true;
                cnx.añadirStock(txtProd.Text, Convert.ToInt32(txtcantidad.Text), txtProve.Text); ;
                mandarMail(imprimirTicket(), txtProve.Text);

            }
            else
            {
                MessageBox.Show("No existe la fruta");

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // String tienda = Interaction.InputBox("Intorudce la tienda");
            lisfrutas = cnx.mostrarTienda("frutas");
            for (int i = 0; i < lisfrutas.Count; i++)
            {
                if (lisfrutas[i].Stock < lisfrutas[i].StockMinimo)
                {
                    dgvStockNecesario.DataSource = null;
                    List<frutas> frt = new List<frutas>();
                    frt.Add(lisfrutas[i]);
                    dgvStockNecesario.DataSource = frt;
                    dgvStockNecesario.Visible = true;
                    Proveedores pv = listProves.Find(x => x.Especialidad == lisfrutas[i].Nombre);
                    if (pv != null)
                    {

                        String error = cnx.añadirStock(lisfrutas[i].Nombre, (lisfrutas[i].StockMinimo - lisfrutas[i].Stock) + 30, pv.Email);
                        MessageBox.Show(error);
                        mandarMail(imprimirTicket(), pv.Email);


                    }
                    else
                    {
                        Proveedores pv2 = listProves.Find(x => x.Especialidad == "General");
                        String error = cnx.añadirStock(lisfrutas[i].Nombre, (lisfrutas[i].StockMinimo - lisfrutas[i].Stock) + 30, pv2.Email);
                        MessageBox.Show(error);
                        mandarMail(imprimirTicket(), pv2.Email);
                    }
                }
            }

        }
        private String imprimirTicket()
        {
            //crear objeto pdfTAble a partir del datagrid
            PdfPTable pdfTable = new PdfPTable(dgvStockNecesario.ColumnCount);
            //separación texto de las celdas del contenido
            pdfTable.DefaultCell.Padding = 3;
            //ancho de la tabla
            pdfTable.WidthPercentage = 80;
            //alineación del texto dentro de las celdas
            pdfTable.HorizontalAlignment = Element.ALIGN_CENTER;
            //ancho del borde
            pdfTable.DefaultCell.BorderWidth = 1;
            //encabezamiento de las columnas
            foreach (DataGridViewColumn column in dgvStockNecesario.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdfTable.AddCell(cell);
            }
            //contenidos de las filas
            foreach (DataGridViewRow row in dgvStockNecesario.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    try { pdfTable.AddCell(cell.Value.ToString()); }
                    catch { }
                }
            }
            //etiqueta con el total a pagar
            PdfPCell cellTotal = new PdfPCell(new Phrase("lblTotal.Text"));
            PdfPCell celdaVacia = new PdfPCell(new Phrase(""));
            pdfTable.AddCell(celdaVacia);
            pdfTable.AddCell(celdaVacia);
            pdfTable.AddCell(celdaVacia);
            pdfTable.AddCell("Total:");
            pdfTable.AddCell(cellTotal);
            string folderPath = "C:\\ticketMouhcine\\";
            //si no existe el directorio ticket se genera
            if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }
            //para colocar la fecha actual de impresión
            DateTime dt = DateTime.Now;
            string s = dt.ToString("yyyyMMddHHmmss");
            string cadenaFinal = folderPath + "ticketMou" + s + ".pdf";
            //crear el documento o fichero físico
            using (FileStream stream = new FileStream(folderPath + "ticketMou" + s + ".pdf", FileMode.Create))
            {
                //dimensiones del documento
                Document pdfDoc = new Document(PageSize.A4, 20f, 20f, 20f, 20f);
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                //incluir una imagen, indicar la ruta
                string patimagen = Path.Combine(Application.StartupPath, "logo.png");
                //integrar la imagen con dimensiones en el pdfdoc
                iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(patimagen);
                img.ScaleAbsolute(270, 150);
                img.ScalePercent(40);
                pdfDoc.Add(img);
                //texto informativo
                pdfDoc.Add(new Paragraph("Fruteria Fernandez"));
                pdfDoc.Add(new Paragraph("CIF: 25487542"));
                pdfDoc.Add(new Paragraph("c/ MANUEL ALSINA s/n"));
                pdfDoc.Add(new Paragraph("10300 Talayuela "));
                pdfDoc.Add(new Paragraph("Cáceres."));
                pdfDoc.Add(new Paragraph("\n\n"));
                //integrar la tabla creada en la parte superior
                pdfDoc.Add(pdfTable);
                pdfDoc.Add(new Paragraph("\n\n"));
                //más información
                pdfDoc.Add(new Paragraph("Fecha/Hora Compra: " + DateTime.Now.ToString("dd-MM-yy, HH:mm:ss")));
                pdfDoc.Add(new Paragraph("Le atendió: Musin"));
                pdfDoc.Close();
            }
            //proceso de windows para levantar en pantalla el pdf
            Process pc = new Process();
            pc.StartInfo.FileName = cadenaFinal;
            pc.Start();
            return cadenaFinal;
        }

        // Mandar mail y adjuntar archivosssss
        private void mandarMail(String archivo, String mail)
        {
            try
            {
                //correo saliente y pwd
                string email = "melmouhcine03@educarex.es";
                string password = "bnchzvuyycdqcdva";
                //activar las credenciales
                var loginInfo = new NetworkCredential(email, password);
                //construir el mensaje
                var msg = new MailMessage();
                //protocolo smtp
                var smtpClient = new SmtpClient("smtp.gmail.com", 25);
                //correo saliente
                msg.From = new MailAddress("melmouhcine03@educarex.es");
                //correo destinatario
                msg.To.Add(new MailAddress(mail));
                //asunto
                msg.Subject = "Compra en Frutería Fernandez";
                //cuerpo del mensaje
                msg.Body = "Gracias por su compra.";
                //adjuntar fichero
                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(archivo);
                msg.Attachments.Add(attachment);
                msg.IsBodyHtml = true;
                //activar protocolos de segunridad
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = loginInfo;
                //enviar el mensaje
                smtpClient.Send(msg);
                //limpiar el canal de salida
                smtpClient.Dispose();
                MessageBox.Show("Mensaje enviado");
            }
            catch (Exception) { MessageBox.Show("Mensaje no enviado"); }
        }
        private void btnOpciones_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();

        }

        private void txtProd_TextChanged(object sender, EventArgs e)
        {
            txtProve.Text = "";

            Proveedores pb = listProves.Find(x => x.Especialidad == txtProd.Text);
            if (pb != null)
            {
                txtProve.Text = pb.Email;
            }
            else
            {
                txtProve.Text = "profeaugustobriga@gmail.com";
            }
        }
        
       

        private void btn_Salir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnGenerarInforme_Click(object sender, EventArgs e)
        {
            Facturacion lr = cnx.obtenerDiaMasVentas();
            dgvInforme.Columns.Add("DIA VENTA", "Dia con más venta");
            dgvInforme.Columns.Add("CANTIDAD", "Cantidad €");
            dgvInforme.Rows.Add(lr.Fecha.ToString().Substring(1,10), lr.Total + "€");
            Facturacion lr2 = cnx.obtenerHoraMasVentas();
            dgvInforme.Rows.Add("Hora del dia con más ventas", "Cantidad " + "€");
            //SELECT * from empleados order by ventas desc limit 1;
            dgvInforme.Rows.Add(lr2.CadenaProd,lr2.Total + "€");
            Empleados emp0 = cnx.obtenerEmpMasVentas();
            dgvInforme.Rows.Add("Empleado con más ventas", "Cantidad de Venta " + "€");
            dgvInforme.Rows.Add("Dni: " + emp0.Dni, emp0.Ventas + "€");
            mandarMailInforme(imprimirTicketInforme(),"melmouhcine03@educarex.es");

        }
        private String imprimirTicketInforme()
        {
            //crear objeto pdfTAble a partir del datagrid
            PdfPTable pdfTable = new PdfPTable(dgvInforme.ColumnCount);
            //separación texto de las celdas del contenido
            pdfTable.DefaultCell.Padding = 3;
            //ancho de la tabla
            pdfTable.WidthPercentage = 80;
            //alineación del texto dentro de las celdas
            pdfTable.HorizontalAlignment = Element.ALIGN_CENTER;
            //ancho del borde
            pdfTable.DefaultCell.BorderWidth = 1;
            //encabezamiento de las columnas
            foreach (DataGridViewColumn column in dgvInforme.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdfTable.AddCell(cell);
            }
            //contenidos de las filas
            foreach (DataGridViewRow row in dgvInforme.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        pdfTable.AddCell(cell.Value.ToString());
                    }
                    else
                    {
                        pdfTable.AddCell("");
                    }
                }
            }
            string folderPath = "C:\\ticketMouhcine\\";
            //si no existe el directorio ticket se genera
            if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }
            //para colocar la fecha actual de impresión
            DateTime dt = DateTime.Now;
            string s = dt.ToString("yyyyMMddHHmmss");
            string cadenaFinal = folderPath + "ticketMou" + s + ".pdf";
            //crear el documento o fichero físico
            using (FileStream stream = new FileStream(folderPath + "ticketMou" + s + ".pdf", FileMode.Create))
            {
                //dimensiones del documento
                Document pdfDoc = new Document(PageSize.A4, 20f, 20f, 20f, 20f);
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                //incluir una imagen, indicar la ruta
                string patimagen = Path.Combine(Application.StartupPath, "logo.png");
                //integrar la imagen con dimensiones en el pdfdoc
                iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(patimagen);
                img.ScaleAbsolute(270, 150);
                img.ScalePercent(40);
                pdfDoc.Add(img);
                //texto informativo
                pdfDoc.Add(new Paragraph("Fruteria Fernandez"));
                pdfDoc.Add(new Paragraph("CIF: 25487542"));
                pdfDoc.Add(new Paragraph("c/ MANUEL ALSINA s/n"));
                pdfDoc.Add(new Paragraph("10300 Talayuela "));
                pdfDoc.Add(new Paragraph("Cáceres."));
                pdfDoc.Add(new Paragraph("\n\n"));
                //integrar la tabla creada en la parte superior
                pdfDoc.Add(pdfTable);
                pdfDoc.Add(new Paragraph("\n\n"));
                //más información
                pdfDoc.Add(new Paragraph("Informe generado por administrador"));
                pdfDoc.Close();
            }
            //proceso de windows para levantar en pantalla el pdf
            Process pc = new Process();
            pc.StartInfo.FileName = cadenaFinal;
            pc.Start();
            return cadenaFinal;
        }

        // Mandar mail y adjuntar archivosssss
        private void mandarMailInforme(String archivo, String mail)
        {
            try
            {
                //correo saliente y pwd
                string email = "melmouhcine03@educarex.es";
                string password = "bnchzvuyycdqcdva";
                //activar las credenciales
                var loginInfo = new NetworkCredential(email, password);
                //construir el mensaje
                var msg = new MailMessage();
                //protocolo smtp
                var smtpClient = new SmtpClient("smtp.gmail.com", 25);
                //correo saliente
                
                msg.From = new MailAddress("macamachor01@educarex.es");
                //correo destinatario
                msg.To.Add(new MailAddress(mail));
                //asunto
                msg.Subject = "Compra en Frutería Fernandez";
                //cuerpo del mensaje
                msg.Body = "Gracias por su compra.";
                //adjuntar fichero
                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(archivo);
                msg.Attachments.Add(attachment);
                msg.IsBodyHtml = true;
                //activar protocolos de segunridad
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = loginInfo;
                //enviar el mensaje
                smtpClient.Send(msg);
                //limpiar el canal de salida
                smtpClient.Dispose();
                MessageBox.Show("Mensaje enviado");
            }
            catch (Exception) { MessageBox.Show("Mensaje no enviado"); }
        }
    }
    
}
