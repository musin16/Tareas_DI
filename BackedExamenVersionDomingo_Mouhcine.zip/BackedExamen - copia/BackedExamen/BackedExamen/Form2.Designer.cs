﻿
namespace BackedExamen
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBajaEmpleado = new System.Windows.Forms.Button();
            this.cmbDarBaja = new System.Windows.Forms.ComboBox();
            this.btnSeleccionarTienda = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnSelecFacturacion = new System.Windows.Forms.Button();
            this.btnSeleccionProved = new System.Windows.Forms.Button();
            this.btnSeleccCliente = new System.Windows.Forms.Button();
            this.btn_SeleccionEmpleados = new System.Windows.Forms.Button();
            this.cmbFrutasTablas = new System.Windows.Forms.ComboBox();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnDarAlta = new System.Windows.Forms.Button();
            this.cmbCliEmp = new System.Windows.Forms.ComboBox();
            this.gbEmpleado = new System.Windows.Forms.GroupBox();
            this.txtPasswordAlta = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.btnAnadirEmp = new System.Windows.Forms.Button();
            this.txtNivelAlta = new System.Windows.Forms.TextBox();
            this.txtDniEmpAlta = new System.Windows.Forms.TextBox();
            this.lblNivel = new System.Windows.Forms.Label();
            this.lblDniEmpAlta = new System.Windows.Forms.Label();
            this.gbCliente = new System.Windows.Forms.GroupBox();
            this.btnInsertarCliente = new System.Windows.Forms.Button();
            this.txtPyuntos = new System.Windows.Forms.TextBox();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.txtnoM = new System.Windows.Forms.TextBox();
            this.txtdniCLI = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAccederOpcion = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanel1.SuspendLayout();
            this.gbEmpleado.SuspendLayout();
            this.gbCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBajaEmpleado
            // 
            this.btnBajaEmpleado.Location = new System.Drawing.Point(58, 101);
            this.btnBajaEmpleado.Name = "btnBajaEmpleado";
            this.btnBajaEmpleado.Size = new System.Drawing.Size(153, 40);
            this.btnBajaEmpleado.TabIndex = 16;
            this.btnBajaEmpleado.Text = "Dar de Baja";
            this.btnBajaEmpleado.UseVisualStyleBackColor = true;
            this.btnBajaEmpleado.Click += new System.EventHandler(this.btn_Baja);
            // 
            // cmbDarBaja
            // 
            this.cmbDarBaja.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDarBaja.FormattingEnabled = true;
            this.cmbDarBaja.Location = new System.Drawing.Point(69, 181);
            this.cmbDarBaja.Name = "cmbDarBaja";
            this.cmbDarBaja.Size = new System.Drawing.Size(121, 28);
            this.cmbDarBaja.TabIndex = 17;
            this.cmbDarBaja.Visible = false;
            this.cmbDarBaja.SelectedIndexChanged += new System.EventHandler(this.cmbDarBaja_SelectedIndexChanged);
            // 
            // btnSeleccionarTienda
            // 
            this.btnSeleccionarTienda.Location = new System.Drawing.Point(58, 14);
            this.btnSeleccionarTienda.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSeleccionarTienda.Name = "btnSeleccionarTienda";
            this.btnSeleccionarTienda.Size = new System.Drawing.Size(153, 65);
            this.btnSeleccionarTienda.TabIndex = 18;
            this.btnSeleccionarTienda.Text = "Seleccionar una tabla";
            this.btnSeleccionarTienda.UseVisualStyleBackColor = true;
            this.btnSeleccionarTienda.Click += new System.EventHandler(this.btnSeleccionarTienda_Click_1);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnSelecFacturacion);
            this.flowLayoutPanel1.Controls.Add(this.btnSeleccionProved);
            this.flowLayoutPanel1.Controls.Add(this.btnSeleccCliente);
            this.flowLayoutPanel1.Controls.Add(this.btn_SeleccionEmpleados);
            this.flowLayoutPanel1.Controls.Add(this.cmbFrutasTablas);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(285, 14);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(633, 43);
            this.flowLayoutPanel1.TabIndex = 19;
            this.flowLayoutPanel1.Visible = false;
            // 
            // btnSelecFacturacion
            // 
            this.btnSelecFacturacion.Location = new System.Drawing.Point(4, 5);
            this.btnSelecFacturacion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSelecFacturacion.Name = "btnSelecFacturacion";
            this.btnSelecFacturacion.Size = new System.Drawing.Size(112, 35);
            this.btnSelecFacturacion.TabIndex = 0;
            this.btnSelecFacturacion.Text = "Facturacion";
            this.btnSelecFacturacion.UseVisualStyleBackColor = true;
            this.btnSelecFacturacion.Click += new System.EventHandler(this.btnSelecFacturacion_Click);
            // 
            // btnSeleccionProved
            // 
            this.btnSeleccionProved.Location = new System.Drawing.Point(124, 5);
            this.btnSeleccionProved.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSeleccionProved.Name = "btnSeleccionProved";
            this.btnSeleccionProved.Size = new System.Drawing.Size(116, 38);
            this.btnSeleccionProved.TabIndex = 2;
            this.btnSeleccionProved.Text = "Proveedores";
            this.btnSeleccionProved.UseVisualStyleBackColor = true;
            this.btnSeleccionProved.Click += new System.EventHandler(this.btnSeleccionProved_Click);
            // 
            // btnSeleccCliente
            // 
            this.btnSeleccCliente.Location = new System.Drawing.Point(248, 5);
            this.btnSeleccCliente.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSeleccCliente.Name = "btnSeleccCliente";
            this.btnSeleccCliente.Size = new System.Drawing.Size(116, 38);
            this.btnSeleccCliente.TabIndex = 3;
            this.btnSeleccCliente.Text = "Clientes";
            this.btnSeleccCliente.UseVisualStyleBackColor = true;
            this.btnSeleccCliente.Click += new System.EventHandler(this.btnSeleccCliente_Click);
            // 
            // btn_SeleccionEmpleados
            // 
            this.btn_SeleccionEmpleados.Location = new System.Drawing.Point(372, 5);
            this.btn_SeleccionEmpleados.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_SeleccionEmpleados.Name = "btn_SeleccionEmpleados";
            this.btn_SeleccionEmpleados.Size = new System.Drawing.Size(116, 38);
            this.btn_SeleccionEmpleados.TabIndex = 4;
            this.btn_SeleccionEmpleados.Text = "Empleados";
            this.btn_SeleccionEmpleados.UseVisualStyleBackColor = true;
            this.btn_SeleccionEmpleados.Click += new System.EventHandler(this.btn_SeleccionEmpleados_Click);
            // 
            // cmbFrutasTablas
            // 
            this.cmbFrutasTablas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrutasTablas.FormattingEnabled = true;
            this.cmbFrutasTablas.Location = new System.Drawing.Point(495, 3);
            this.cmbFrutasTablas.Name = "cmbFrutasTablas";
            this.cmbFrutasTablas.Size = new System.Drawing.Size(121, 28);
            this.cmbFrutasTablas.TabIndex = 5;
            this.cmbFrutasTablas.SelectedIndexChanged += new System.EventHandler(this.cmbFrutasTablas_SelectedIndexChanged);
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(1007, 593);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(131, 45);
            this.btnVolver.TabIndex = 20;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnDarAlta
            // 
            this.btnDarAlta.Location = new System.Drawing.Point(58, 272);
            this.btnDarAlta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDarAlta.Name = "btnDarAlta";
            this.btnDarAlta.Size = new System.Drawing.Size(153, 65);
            this.btnDarAlta.TabIndex = 21;
            this.btnDarAlta.Text = "Dar alta";
            this.btnDarAlta.UseVisualStyleBackColor = true;
            this.btnDarAlta.Click += new System.EventHandler(this.btnDarAlta_Click);
            // 
            // cmbCliEmp
            // 
            this.cmbCliEmp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCliEmp.FormattingEnabled = true;
            this.cmbCliEmp.Location = new System.Drawing.Point(569, 266);
            this.cmbCliEmp.Name = "cmbCliEmp";
            this.cmbCliEmp.Size = new System.Drawing.Size(176, 28);
            this.cmbCliEmp.TabIndex = 22;
            this.cmbCliEmp.Visible = false;
            this.cmbCliEmp.SelectedIndexChanged += new System.EventHandler(this.cmbCliEmp_SelectedIndexChanged);
            // 
            // gbEmpleado
            // 
            this.gbEmpleado.Controls.Add(this.txtPasswordAlta);
            this.gbEmpleado.Controls.Add(this.lblPassword);
            this.gbEmpleado.Controls.Add(this.btnAnadirEmp);
            this.gbEmpleado.Controls.Add(this.txtNivelAlta);
            this.gbEmpleado.Controls.Add(this.txtDniEmpAlta);
            this.gbEmpleado.Controls.Add(this.lblNivel);
            this.gbEmpleado.Controls.Add(this.lblDniEmpAlta);
            this.gbEmpleado.Location = new System.Drawing.Point(228, 266);
            this.gbEmpleado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbEmpleado.Name = "gbEmpleado";
            this.gbEmpleado.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbEmpleado.Size = new System.Drawing.Size(334, 254);
            this.gbEmpleado.TabIndex = 23;
            this.gbEmpleado.TabStop = false;
            this.gbEmpleado.Text = "Empleado";
            this.gbEmpleado.Visible = false;
            // 
            // txtPasswordAlta
            // 
            this.txtPasswordAlta.Location = new System.Drawing.Point(142, 74);
            this.txtPasswordAlta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPasswordAlta.Name = "txtPasswordAlta";
            this.txtPasswordAlta.Size = new System.Drawing.Size(148, 26);
            this.txtPasswordAlta.TabIndex = 12;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(23, 74);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(78, 20);
            this.lblPassword.TabIndex = 11;
            this.lblPassword.Text = "Password";
            // 
            // btnAnadirEmp
            // 
            this.btnAnadirEmp.Location = new System.Drawing.Point(102, 196);
            this.btnAnadirEmp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAnadirEmp.Name = "btnAnadirEmp";
            this.btnAnadirEmp.Size = new System.Drawing.Size(112, 35);
            this.btnAnadirEmp.TabIndex = 10;
            this.btnAnadirEmp.Text = "Añadir";
            this.btnAnadirEmp.UseVisualStyleBackColor = true;
            this.btnAnadirEmp.Click += new System.EventHandler(this.btnAnadirEmp_Click);
            // 
            // txtNivelAlta
            // 
            this.txtNivelAlta.Location = new System.Drawing.Point(142, 119);
            this.txtNivelAlta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNivelAlta.Name = "txtNivelAlta";
            this.txtNivelAlta.Size = new System.Drawing.Size(148, 26);
            this.txtNivelAlta.TabIndex = 8;
            // 
            // txtDniEmpAlta
            // 
            this.txtDniEmpAlta.Location = new System.Drawing.Point(142, 25);
            this.txtDniEmpAlta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDniEmpAlta.Name = "txtDniEmpAlta";
            this.txtDniEmpAlta.Size = new System.Drawing.Size(148, 26);
            this.txtDniEmpAlta.TabIndex = 7;
            // 
            // lblNivel
            // 
            this.lblNivel.AutoSize = true;
            this.lblNivel.Location = new System.Drawing.Point(23, 122);
            this.lblNivel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNivel.Name = "lblNivel";
            this.lblNivel.Size = new System.Drawing.Size(42, 20);
            this.lblNivel.TabIndex = 5;
            this.lblNivel.Text = "Nivel";
            // 
            // lblDniEmpAlta
            // 
            this.lblDniEmpAlta.AutoSize = true;
            this.lblDniEmpAlta.Location = new System.Drawing.Point(23, 25);
            this.lblDniEmpAlta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDniEmpAlta.Name = "lblDniEmpAlta";
            this.lblDniEmpAlta.Size = new System.Drawing.Size(33, 20);
            this.lblDniEmpAlta.TabIndex = 4;
            this.lblDniEmpAlta.Text = "Dni";
            // 
            // gbCliente
            // 
            this.gbCliente.Controls.Add(this.btnInsertarCliente);
            this.gbCliente.Controls.Add(this.txtPyuntos);
            this.gbCliente.Controls.Add(this.txtMail);
            this.gbCliente.Controls.Add(this.txtnoM);
            this.gbCliente.Controls.Add(this.txtdniCLI);
            this.gbCliente.Controls.Add(this.label4);
            this.gbCliente.Controls.Add(this.label3);
            this.gbCliente.Controls.Add(this.label2);
            this.gbCliente.Controls.Add(this.label1);
            this.gbCliente.Location = new System.Drawing.Point(752, 266);
            this.gbCliente.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCliente.Name = "gbCliente";
            this.gbCliente.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCliente.Size = new System.Drawing.Size(313, 268);
            this.gbCliente.TabIndex = 24;
            this.gbCliente.TabStop = false;
            this.gbCliente.Text = "Cliente";
            this.gbCliente.Visible = false;
            // 
            // btnInsertarCliente
            // 
            this.btnInsertarCliente.Location = new System.Drawing.Point(102, 225);
            this.btnInsertarCliente.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnInsertarCliente.Name = "btnInsertarCliente";
            this.btnInsertarCliente.Size = new System.Drawing.Size(112, 35);
            this.btnInsertarCliente.TabIndex = 8;
            this.btnInsertarCliente.Text = "Insertar";
            this.btnInsertarCliente.UseVisualStyleBackColor = true;
            this.btnInsertarCliente.Click += new System.EventHandler(this.btnInsertarCliente_Click);
            // 
            // txtPyuntos
            // 
            this.txtPyuntos.Location = new System.Drawing.Point(158, 177);
            this.txtPyuntos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPyuntos.Name = "txtPyuntos";
            this.txtPyuntos.Size = new System.Drawing.Size(148, 26);
            this.txtPyuntos.TabIndex = 7;
            // 
            // txtMail
            // 
            this.txtMail.Location = new System.Drawing.Point(158, 135);
            this.txtMail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(148, 26);
            this.txtMail.TabIndex = 6;
            // 
            // txtnoM
            // 
            this.txtnoM.Location = new System.Drawing.Point(158, 80);
            this.txtnoM.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnoM.Name = "txtnoM";
            this.txtnoM.Size = new System.Drawing.Size(148, 26);
            this.txtnoM.TabIndex = 5;
            // 
            // txtdniCLI
            // 
            this.txtdniCLI.Location = new System.Drawing.Point(158, 31);
            this.txtdniCLI.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtdniCLI.Name = "txtdniCLI";
            this.txtdniCLI.Size = new System.Drawing.Size(148, 26);
            this.txtdniCLI.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 188);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "puntos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 135);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 91);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "dni";
            // 
            // btnAccederOpcion
            // 
            this.btnAccederOpcion.Location = new System.Drawing.Point(795, 593);
            this.btnAccederOpcion.Name = "btnAccederOpcion";
            this.btnAccederOpcion.Size = new System.Drawing.Size(189, 45);
            this.btnAccederOpcion.TabIndex = 25;
            this.btnAccederOpcion.Text = "Acceder Mas opciones";
            this.btnAccederOpcion.UseVisualStyleBackColor = true;
            this.btnAccederOpcion.Click += new System.EventHandler(this.btnAccederOpcion_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(289, 67);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.Size = new System.Drawing.Size(646, 195);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.btnAccederOpcion);
            this.Controls.Add(this.gbCliente);
            this.Controls.Add(this.gbEmpleado);
            this.Controls.Add(this.cmbCliEmp);
            this.Controls.Add(this.btnDarAlta);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnSeleccionarTienda);
            this.Controls.Add(this.cmbDarBaja);
            this.Controls.Add(this.btnBajaEmpleado);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.gbEmpleado.ResumeLayout(false);
            this.gbEmpleado.PerformLayout();
            this.gbCliente.ResumeLayout(false);
            this.gbCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnBajaEmpleado;
        private System.Windows.Forms.ComboBox cmbDarBaja;
        private System.Windows.Forms.Button btnSeleccionarTienda;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnSelecFacturacion;
        private System.Windows.Forms.Button btnSeleccionProved;
        private System.Windows.Forms.Button btnSeleccCliente;
        private System.Windows.Forms.Button btn_SeleccionEmpleados;
        private System.Windows.Forms.ComboBox cmbFrutasTablas;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Button btnDarAlta;
        private System.Windows.Forms.ComboBox cmbCliEmp;
        private System.Windows.Forms.GroupBox gbEmpleado;
        private System.Windows.Forms.TextBox txtPasswordAlta;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Button btnAnadirEmp;
        private System.Windows.Forms.TextBox txtNivelAlta;
        private System.Windows.Forms.TextBox txtDniEmpAlta;
        private System.Windows.Forms.Label lblNivel;
        private System.Windows.Forms.Label lblDniEmpAlta;
        private System.Windows.Forms.GroupBox gbCliente;
        private System.Windows.Forms.Button btnInsertarCliente;
        private System.Windows.Forms.TextBox txtPyuntos;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.TextBox txtnoM;
        private System.Windows.Forms.TextBox txtdniCLI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAccederOpcion;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}