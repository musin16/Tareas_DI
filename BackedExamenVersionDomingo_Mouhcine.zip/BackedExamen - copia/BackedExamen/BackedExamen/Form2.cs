﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient.Memcached;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackedExamen
{
    public partial class Form2 : Form
    {
        conectarBD cnx=new conectarBD();
        List<Proveedores> proveedores=new List<Proveedores>();
        List<frutas> lfruta=new List<frutas>();
        List<Cliente> listClientes = new List<Cliente>();
        List<Empleados> listempl = new List<Empleados>();
        List<Tiendas> lisTiendas = new List<Tiendas>();
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSeleccionarTienda_Click(object sender, EventArgs e)
        {

            Form1 f=new Form1();    
            
            flowLayoutPanel1.Visible = true;
        }

        private void btn_Baja(object sender, EventArgs e)
        {
            cmbDarBaja.Items.Add("Cliente");
            cmbDarBaja.Items.Add("Empleado");
            cmbDarBaja.Visible = true;
        }

        private void cmbDarBaja_SelectedIndexChanged(object sender, EventArgs e)
        {
            String error = "";
            if (cmbDarBaja.Text.Equals("Cliente"))
            {
                String clien = Interaction.InputBox("Introduce el cliente que quieres dar de baja");
                error=cnx.darBajaCliente(clien);
                if (error==("Se ha dado de baja correctamente al cliente con dni "+ clien))
                {
                    MessageBox.Show(error);
                }
                else
                {
                    MessageBox.Show(error);
                }
            }else if (cmbDarBaja.Text.Equals("Empleado"))
            {
                String empl = Interaction.InputBox("Introduce el empleado que quieres dar de baja");
                error = cnx.darBajaEmpleado(empl);
                if (error.Equals("Se ha dado de baja correctamente al empleado con dni " + empl))
                {
                    MessageBox.Show(error);
                }
                else
                {
                    MessageBox.Show(error);
                }
            }
        }

        private void btnSelecFacturacion_Click(object sender, EventArgs e)
        {
            List<Facturacion> f = cnx.infoTablaFacturacion();
            flowLayoutPanel1.Visible = false;
            flowLayoutPanel1.Visible = true;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = f;
            dataGridView1.Visible = true;
        }

        private void btnSeleccionProved_Click(object sender, EventArgs e)
        {
            proveedores=cnx.obtenerProvedor();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = proveedores;
        }

        private void btnSeleccionarTienda_Click_1(object sender, EventArgs e)
        {
            lisTiendas = cnx.obtenerTiendas();
            for (int i = 0; i < lisTiendas.Count; i++)
            {
                cmbFrutasTablas.Items.Add(lisTiendas[i].Nombre);
            }
            flowLayoutPanel1.Visible = true;
        }

        private void btnSeleccCliente_Click(object sender, EventArgs e)
        {
            listClientes = cnx.obtenerClientes();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listClientes;
        }

        private void btn_SeleccionEmpleados_Click(object sender, EventArgs e)
        {
            listempl = cnx.obtenerUsuario();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listempl;
        }

        private void cmbFrutasTablas_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbDarBaja.Visible = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = cnx.mostrarTienda(cmbFrutasTablas.Text);
            dataGridView1.Visible = true;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
            cmbCliEmp.Items.Add("Cliente");
            cmbCliEmp.Items.Add("Empleado");
        }
        public void ocultar()
        {
            gbCliente.Visible = false;
            gbEmpleado.Visible = false;
            dataGridView1.Visible = false;
            cmbCliEmp.Visible = false;

        }
        private void cmbCliEmp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCliEmp.Text.Equals("Cliente"))
            {
                gbEmpleado.Visible = false;
                gbCliente.Visible = true;
                cmbCliEmp.Visible = true;
            }
            else if (cmbCliEmp.Text.Equals("Empleado"))
            {
                gbCliente.Visible = false;
                gbEmpleado.Visible = true;
            }
        }

        private void btnDarAlta_Click(object sender, EventArgs e)
        {
            ocultar();
            cmbCliEmp.Visible = true;
        }

        private void btnAnadirEmp_Click(object sender, EventArgs e)
        {
            cnx.añadirEmpleado(txtDniEmpAlta.Text, txtPasswordAlta.Text, Convert.ToInt16(txtNivelAlta.Text));
        }

        private void btnInsertarCliente_Click(object sender, EventArgs e)
        {
            cnx.insertarCliente(txtdniCLI.Text, txtnoM.Text, txtMail.Text, Convert.ToInt16(txtPyuntos.Text));
        }

        private void btnAccederOpcion_Click(object sender, EventArgs e)
        {
            Form1 f1=new Form1();
            f1.ShowDialog();
        }
    }
}
