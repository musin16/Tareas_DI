﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackedExamen
{
    public partial class Login : Form
    {
        List<Empleados> lisemp = new List<Empleados>();
        conectarBD cnx = new conectarBD();
        public Login()
        {
            InitializeComponent();
        }

        private void txtcontra_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char) Keys.Enter)
            {
                e.Handled = true;
               List<Empleados> emp = cnx.obtenerUsuario();
                Empleados em = emp.Find(x=>x.Dni==txtEmp.Text);
                if (em!=null) {
                    if (em.Pasword.Equals(CrearMD5(txtcontra.Text)))
                    {
                        if (em.Nivel==1)
                        {
                            conectarBD.cont = 1;
                            Form1 be = new Form1();
                            be.Show();
                        }
                        else
                        {
                            Form2 be = new Form2();
                            be.Show();
                        }
                      
                    }
                    else
                    {
                        MessageBox.Show("contraseña incorrecta");
                    }
                }
                else
                {
                    MessageBox.Show("Usuario no existe");
                }
            }
        }
        public static string CrearMD5(string pwd)
        {
            // se pasa como parámetro el contenido del cuadro de texto
           
            using (System.Security.Cryptography.MD5 md5 =
             System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes =
               System.Text.Encoding.ASCII.GetBytes(pwd);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // convertir el array de byte en un string hexadecimal
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    //x2 es un argumento, parámetro para decir que se formatea
                   // en hexadecimal
                sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString().ToLower();
            }
        }

        private void txtEmp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)Keys.Enter)
            {
                e.Handled = true;
                txtcontra.Focus();
            }
        }
    }
}
