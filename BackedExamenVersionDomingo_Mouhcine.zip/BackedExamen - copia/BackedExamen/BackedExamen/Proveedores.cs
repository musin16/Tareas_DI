﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackedExamen
{
    class Proveedores
    {
        string cifProvedor;
        string nombre;
        string email;
        string especialidad;

        public Proveedores()
        {
        }

        public Proveedores(string cifProvedor, string nombre, string email, string especialidad)
        {
            this.CifProvedor = cifProvedor;
            this.Nombre = nombre;
            this.Email = email;
            this.Especialidad = especialidad;
        }

        public string CifProvedor { get => cifProvedor; set => cifProvedor = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Email { get => email; set => email = value; }
        public string Especialidad { get => especialidad; set => especialidad = value; }
    }
}
