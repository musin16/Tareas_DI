﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BackedExamen;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using MySql.Data.MySqlClient.Memcached;

namespace BackedExamen
{
    class conectarBD
    {
        MySqlConnection conexion;
        MySqlCommand comando;
        MySqlDataReader data;
        public static int cont;
        public conectarBD()
        {
            conexion = new MySqlConnection();
            conexion.ConnectionString = "server=localhost;Database=frutasmoralas;Uid=root;pwd='';old guids=true";
        }

        internal string  crearTienda(string frutas)
        {
            string error = "Se ha creado correctamente la tienda";
            try
            {
                conexion.Open();
                String consulta = "CREATE TABLE " + frutas +
                    "( `id` int(11) NOT NULL," +
                    "`nombre` varchar(25) COLLATE latin1_spanish_ci NOT NULL," +
                    " `precio` float NOT NULL," +
                    "`imagen` mediumblob NOT NULL," +
                    "`procedencia` varchar(100) COLLATE latin1_spanish_ci NOT NULL," +
                    "`stock` int(11) NOT NULL," +
                    "`activo` int(11) NOT NULL," +
                    "`stockMinimo` int(11) NOT NULL" +
                    ") ENGINE = InnoDB DEFAULT CHARSET = latin1 " +
                    "COLLATE = latin1_spanish_ci;"
                ;
                comando = new MySqlCommand(consulta, conexion);
                comando.ExecuteNonQuery();
                conexion.Close();
            }catch (MySqlException ex)
            {
                error=ex.Message;
            }
            finally
            {
                conexion.Close();
            }
            return error;
        }

        internal void insertarCliente(string dn, string nom, string mel, int puntos)
        {
            conexion.Open();
            comando = new MySqlCommand("Insert into clientes VALUES(?dn,?nom,?mel,?punt) ", conexion);
            comando.Parameters.AddWithValue("?dn", dn);
            comando.Parameters.AddWithValue("?nom", nom);
            comando.Parameters.AddWithValue("?mel", mel);
            comando.Parameters.AddWithValue("?punt", puntos);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        internal List<Proveedores> obtenerProvedor()
        {
            List<Proveedores> lisPro = new List<Proveedores>();
            conexion.Open();
            comando = new MySqlCommand("Select * from proveedores", conexion);
            data= comando.ExecuteReader();
            while (data.Read())
            {
                Proveedores e = new Proveedores();
                e.CifProvedor = data.GetString(0);
                e.Nombre = data.GetString(1);
                e.Email =data.GetString(2);
                e.Especialidad = data.GetString(3);
                lisPro.Add(e);
            }
            conexion.Close();
            return lisPro;
        }

        internal string añadirStock( string fruta, int cant,string prov)
        {
            String error = "Se ha solicitado el stock de " +fruta +" correctamente al provedoor " + prov;
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Update frutas SET stock=stock+?cant where nombre=?fruta", conexion);
                comando.Parameters.AddWithValue("?cant", cant);
                comando.Parameters.AddWithValue("?fruta", fruta);
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (MySqlException ex)
            {
                error = ex.Message;
            }
            finally
            {
                conexion.Close();
            }
            return error;
        }

        internal string borrarTabla(string tabla)
        {
            String error = "Se ha borrado correctamente la tabla";
            try
            {
                conexion.Open();
                comando = new MySqlCommand("drop table " + tabla, conexion);
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                error = ex.Message;
            }
            finally
            {
                conexion.Close();
            }
            return error;
        }

        internal List<Empleados> obtenerUsuario()
        {
            List<Empleados> LISemP = new List<Empleados>();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Select * from empleados ", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    Empleados e = new Empleados();
                    e.Dni = data.GetString(0);
                    e.Pasword = data.GetString(1);
                    e.Nivel = Convert.ToInt32(data.GetString(2));
                    e.Ventas = Convert.ToInt32(data.GetString(3));
                    LISemP.Add(e);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
            return LISemP;
        }

        internal List<Facturacion> infoTablaFacturacion()
        {
            List<Facturacion> fact = new List<Facturacion>();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Select * from facturacion", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    Facturacion f = new Facturacion();
                    f.Fecha = (DateTime)data["fecha"];
                    f.Mail = data.GetString(1);
                    f.CadenaProd = data.GetString(2);
                    f.Total = data.GetFloat(4);
                    f.Indice = data.GetInt16(0);
                    fact.Add(f);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }

            return fact;
        }

        internal void añadirEmpleado(string dn, string pwd, int nivel)
        {
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Insert into empleados VALUES(?dn,?pwd,?nivel,0) ", conexion);
                comando.Parameters.AddWithValue("?dn", dn);
                comando.Parameters.AddWithValue("?pwd", pwd);
                comando.Parameters.AddWithValue("?nivel", nivel);
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        internal List<Tiendas> obtenerTiendas()
        {
            List<Tiendas> listTien = new List<Tiendas>();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Select * from tiendas", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    Tiendas f = new Tiendas();
                    f.Nombre = data.GetString(1);
                    f.Id = data.GetInt16(0);
                    listTien.Add(f);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }

            return listTien;
       
        }

        internal void insertarTienda(string tienda)
        {
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Insert into tiendas VALUES(null,?nombreTienda)", conexion);
                comando.Parameters.AddWithValue("?nombreTienda", tienda);
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        internal void borrarTienda(string tabla)
        {
            try
            {
                conexion.Open();
                comando = new MySqlCommand("DELETE FROM tiendas WHERE nombre=?tabla", conexion);
                comando.Parameters.AddWithValue("?tabla",tabla);
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        internal List<frutas> mostrarTienda(string tiendaConsultar)
        {
           List<frutas> tienda = new List<frutas>();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Select * from "+ tiendaConsultar, conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    frutas f=new frutas();
                    f.Id = data.GetInt16(0);
                    f.Nombre = data.GetString(1);
                    f.Precio=data.GetFloat(2);
                    f.Imagen =( byte[] ) data["imagen"];
                    f.Procedencia= data.GetString(4);
                    f.Stock = data.GetInt32(5);
                    f.Activo = data.GetInt16(6);
                    f.StockMinimo = data.GetInt32(7);
                    tienda.Add(f);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }

            return tienda;
        }

        internal string darBajaEmpleado(string dni)
        {
            string error = "Se ha dado de baja correctamente al empleado con dni " + dni;
            try {
                conexion.Open();
                comando = new MySqlCommand("DELETE FROM empleados WHERE dni=" + dni, conexion);
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (MySqlException ex)
            {
                error=ex.Message;
            }
            finally
            {
                conexion.Close();
            }

            return error;
        }
        internal string darBajaCliente(string dni)
        {
            string error = "Se ha dado de baja correctamente al cliente con dni " + dni;
            try
            {
                conexion.Open();
                comando = new MySqlCommand("DELETE FROM clientes WHERE dni=?dni", conexion);
                comando.Parameters.AddWithValue("?dni",dni);
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (MySqlException ex)
            {
                error = ex.Message;
            }
            finally
            {
                conexion.Close();
            }

            return error;
        }

        internal List<Cliente> obtenerClientes()
        {
            List<Cliente> listClien = new List<Cliente>();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("Select * from empleados ", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    Cliente e = new Cliente();
                    e.Dni = data.GetString(0);
                    e.Nombre = data.GetString(1);
                    e.Email = data.GetString(2);
                    e.Puntos = Convert.ToInt32(data.GetString(3));
                    listClien.Add(e);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
            return listClien;
        }

        internal Facturacion obtenerDiaMasVentas()
        {
            Facturacion fax = new Facturacion();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("SELECT DATE(Fecha),ROUND(SUM(Total),2) FROM facturacion GROUP BY DATE(Fecha) ORDER BY 2 DESC LIMIT 1", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    fax.Fecha = data.GetDateTime(0);
                    fax.Total = data.GetFloat(1);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
            return fax;
        }

        internal Facturacion obtenerHoraMasVentas()
        {
            Facturacion fax = new Facturacion();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("SELECT CONCAT(HOUR(Fecha),\":\" ,MINUTE(Fecha),\":\", SECOND(Fecha)),ROUND((Total),2) FROM facturacion GROUP BY DATE(Fecha) ORDER BY 2 DESC LIMIT 1;", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    fax.CadenaProd = data.GetString(0);
                    fax.Total = data.GetFloat(1);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
            return fax;
        }

        internal Empleados obtenerEmpMasVentas()
        {
            Empleados emp = new Empleados();
            try
            {
                conexion.Open();
                comando = new MySqlCommand("SELECT dni,ventas from empleados order by ventas desc limit 1;", conexion);
                data = comando.ExecuteReader();
                while (data.Read())
                {
                    emp.Dni = data.GetString(0);
                    emp.Ventas = data.GetInt16(1);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
            return emp;
        }
    }
}
