﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackedExamen
{
    class frutas
    {
        int id;
        string nombre;
        float precio;
        byte[] imagen;
        string procedencia;
        int activo;
        int stock;
        int stockMinimo;

        public frutas()
        {
        }

        public frutas(int id, string nombre, float precio, byte[] imagen, string procedencia, int activo, int stock, int stockMinimo)
        {
            this.Id = id;
            this.Nombre = nombre;
            this.Precio = precio;
            this.Imagen = imagen;
            this.Procedencia = procedencia;
            this.Activo = activo;
            this.Stock = stock;
            this.StockMinimo = stockMinimo;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public float Precio { get => precio; set => precio = value; }
        public byte[] Imagen { get => imagen; set => imagen = value; }
        public string Procedencia { get => procedencia; set => procedencia = value; }
        public int Activo { get => activo; set => activo = value; }
        public int Stock { get => stock; set => stock = value; }
        public int StockMinimo { get => stockMinimo; set => stockMinimo = value; }
    }
}
